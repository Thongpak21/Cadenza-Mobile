//
//  People.m
//  PersonalTester
//
//  Created by Witawat Wanamonthon on 11/02/2016.
//  Copyright © 2016 Witawat Wanamonthon. All rights reserved.
//

#import "People.h"
#import "CreditCard.h"
#import "Job.h"

@implementation People

// Insert code here to add functionality to your managed object subclass

@end
