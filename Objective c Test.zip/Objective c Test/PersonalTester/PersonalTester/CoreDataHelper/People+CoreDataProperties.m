//
//  People+CoreDataProperties.m
//  PersonalTester
//
//  Created by Witawat Wanamonthon on 11/02/2016.
//  Copyright © 2016 Witawat Wanamonthon. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "People+CoreDataProperties.h"

@implementation People (CoreDataProperties)

@dynamic id;
@dynamic people_name;
@dynamic people_birth_date;
@dynamic people_height;
@dynamic people_weight;
@dynamic people_job;
@dynamic people_friends;
@dynamic credit_card_own;

@end
