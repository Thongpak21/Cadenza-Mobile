//
//  CreditCard.m
//  PersonalTester
//
//  Created by Witawat Wanamonthon on 11/02/2016.
//  Copyright © 2016 Witawat Wanamonthon. All rights reserved.
//

#import "CreditCard.h"
#import "People.h"

@implementation CreditCard

// Insert code here to add functionality to your managed object subclass

@end
