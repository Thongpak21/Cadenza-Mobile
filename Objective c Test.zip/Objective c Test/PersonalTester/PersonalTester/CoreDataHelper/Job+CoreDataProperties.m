//
//  Job+CoreDataProperties.m
//  PersonalTester
//
//  Created by Witawat Wanamonthon on 11/02/2016.
//  Copyright © 2016 Witawat Wanamonthon. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Job+CoreDataProperties.h"

@implementation Job (CoreDataProperties)

@dynamic id;
@dynamic job_name;
@dynamic job_salary;
@dynamic job_start_date;
@dynamic job_position;
@dynamic people;

@end
